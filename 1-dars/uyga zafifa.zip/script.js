// 1. Haftadagi kunlar soni: 7 (Doimiy qiymat bo'lgani uchun const)
const haftadagiKunlarSoni = 7;
console.log(haftadagiKunlarSoni);

// 2. Futbol o'yinidagi hisob: 0 (O'yin davomida o'zgarishi mumkinligi uchun let)
let futbolHisobi = 0;
console.log(futbolHisobi);

// 3. Mamlakat nomi: "O'zbekiston" (Doimiy qiymat bo'lgani uchun const)
const mamlakatNomi = "O'zbekiston";
console.log(mamlakatNomi);

// 4. Telefon batareyasi foizi: 85 (Vaqt o'tishi bilan o'zgargani uchun let)
let batareyaFoizi = 85;
console.log(batareyaFoizi);

// 5. Tug'ilgan yilingiz (O'zgarmas ma'lumot bo'lgani uchun const)
const tugilganYil = 2011;
console.log(tugilganYil);

// 6. Bugun o'qilgan kitob sahifalari soni (Ko'payib borishi mumkinligi uchun let)
let oqilganSahifalarSoni = 15;
console.log(oqilganSahifalarSoni);